disp('Fake configure.m function located in /ligo/svncommon/SeiSVN/seismic/MatlabTools/Schroeder_Phase_Scripts/')
pause(10)